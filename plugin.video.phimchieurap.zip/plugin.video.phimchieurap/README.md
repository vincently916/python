This is my test kodi addon.
